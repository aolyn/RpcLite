﻿
namespace RpcLite
{
	public class NullResponse
	{
		public static readonly NullResponse Value = new NullResponse();
		private NullResponse() { }
	}
}
